-- ============================================================
-- HOTD RP — Schéma Supabase CORRIGÉ
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  discord_id TEXT UNIQUE NOT NULL,
  username TEXT NOT NULL,
  discriminator TEXT,
  avatar TEXT,
  email TEXT,
  role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('member', 'moderator', 'admin')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  last_login TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS houses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  sigil TEXT,
  words TEXT,
  description TEXT,
  region TEXT,
  color_primary TEXT DEFAULT '#8B0000',
  color_secondary TEXT DEFAULT '#FFD700',
  is_extinct BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  created_by UUID REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS characters (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  house_id UUID REFERENCES houses(id) ON DELETE SET NULL,
  title TEXT,
  age INTEGER,
  gender TEXT CHECK (gender IN ('male', 'female', 'other', 'unknown')),
  status TEXT DEFAULT 'alive' CHECK (status IN ('alive', 'dead', 'unknown', 'dragon')),
  description TEXT,
  avatar_url TEXT,
  is_dragon BOOLEAN DEFAULT FALSE,
  dragon_name TEXT,
  player_discord_id TEXT,
  player_id UUID REFERENCES users(id) ON DELETE SET NULL,
  is_canon BOOLEAN DEFAULT FALSE,
  is_public BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  created_by UUID REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS relations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  character_a_id UUID NOT NULL REFERENCES characters(id) ON DELETE CASCADE,
  character_b_id UUID NOT NULL REFERENCES characters(id) ON DELETE CASCADE,
  relation_type TEXT NOT NULL CHECK (relation_type IN (
    'parent', 'child', 'sibling', 'spouse', 'betrothed',
    'lover', 'legitimized', 'bastard_of', 'dragon_rider'
  )),
  is_secret BOOLEAN DEFAULT FALSE,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  created_by UUID REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS events (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  description TEXT,
  event_date TEXT,
  event_type TEXT DEFAULT 'rp' CHECK (event_type IN ('birth', 'death', 'marriage', 'war', 'rp', 'announcement')),
  characters_involved UUID[] DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  created_by UUID REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS dragon_claims (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  character_id UUID NOT NULL REFERENCES characters(id) ON DELETE CASCADE,
  dragon_id UUID NOT NULL REFERENCES characters(id) ON DELETE CASCADE,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  claimed_at TIMESTAMPTZ DEFAULT NOW(),
  reviewed_by UUID REFERENCES users(id),
  reviewed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS bot_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  discord_id TEXT NOT NULL,
  command TEXT NOT NULL,
  params JSONB,
  result TEXT,
  success BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- RLS activé mais permissif (contrôle d'accès géré par l'API Next.js)
ALTER TABLE users         ENABLE ROW LEVEL SECURITY;
ALTER TABLE houses        ENABLE ROW LEVEL SECURITY;
ALTER TABLE characters    ENABLE ROW LEVEL SECURITY;
ALTER TABLE relations     ENABLE ROW LEVEL SECURITY;
ALTER TABLE events        ENABLE ROW LEVEL SECURITY;
ALTER TABLE dragon_claims ENABLE ROW LEVEL SECURITY;
ALTER TABLE bot_logs      ENABLE ROW LEVEL SECURITY;

CREATE POLICY "allow_all_characters"    ON characters    USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_houses"        ON houses        USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_relations"     ON relations     USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_events"        ON events        USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_users"         ON users         USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_dragon_claims" ON dragon_claims USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_bot_logs"      ON bot_logs      USING (true) WITH CHECK (true);

-- Trigger updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER characters_updated_at
  BEFORE UPDATE ON characters
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Maisons de base
INSERT INTO houses (name, sigil, words, region, color_primary, color_secondary) VALUES
  ('Targaryen', '🐉', 'Feu et Sang',              'Westeros',     '#8B0000', '#FFD700'),
  ('Velaryon',  '⚓', 'Les Marées nous Appellent', 'Driftmark',    '#003366', '#C0C0C0'),
  ('Hightower', '🏰', 'Nous Sommes la Lumière',    'Villevieille', '#228B22', '#FFFFFF'),
  ('Lannister', '🦁', 'Entends-moi rugir',         'Castral Roc',  '#FFD700', '#8B0000'),
  ('Stark',     '🐺', 'L''Hiver vient',            'Winterfell',   '#808080', '#FFFFFF'),
  ('Baratheon', '🦌', 'Notre est la Fureur',        'Accalmie',     '#FFD700', '#000000')
ON CONFLICT DO NOTHING;
