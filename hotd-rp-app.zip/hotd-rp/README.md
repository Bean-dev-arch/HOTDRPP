# 🐉 HOTD RP — Arbre Généalogique des Sept Couronnes

Application web + bot Discord pour gérer l'arbre généalogique de ton serveur RP House of the Dragon.

---

## 📋 Fonctionnalités

- **Connexion Discord OAuth** — login via Discord
- **Arbre généalogique interactif** — visualisation D3.js avec zoom, drag, filtres par maison
- **Gestion des personnages** — création, modification, suppression
- **Liens familiaux** — parent, enfant, frère/sœur, époux, amant, bâtard, chevaucheur de dragon...
- **Maisons nobles** — Targaryen, Velaryon, Hightower et plus
- **Panneau admin** — gestion complète pour les modérateurs
- **Bot Discord** — commandes slash pour interagir sans quitter Discord

---

## 🚀 Installation

### 1. Prérequis
- Node.js 18+
- Compte Supabase (déjà configuré)
- Application Discord (déjà configurée)

### 2. Cloner et installer

```bash
# Installer les dépendances du site
cd hotd-rp
npm install

# Installer les dépendances du bot
cd bot
npm install
```

### 3. Variables d'environnement

Édite `.env.local` à la racine :

```env
# Discord OAuth (déjà rempli)
DISCORD_CLIENT_ID=1493793870364934144
DISCORD_CLIENT_SECRET=ODcQjVx_-2BOLZrUrvEspAKFl138sxX6

# NextAuth — CHANGE CE SECRET !
NEXTAUTH_URL=https://ton-domaine.com
NEXTAUTH_SECRET=génère-une-chaine-aléatoire-de-32-chars

# Supabase (déjà rempli)
NEXT_PUBLIC_SUPABASE_URL=https://ewpssehydejdciptcoov.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_2rS3Wg94zgW1RT5aErSoHA_LDC1go4r
SUPABASE_SERVICE_ROLE_KEY=eyJhbGci...

# Bot
DISCORD_BOT_TOKEN=TON_BOT_TOKEN
DISCORD_GUILD_ID=ID_DE_TON_SERVEUR
BOT_WEBHOOK_SECRET=un-secret-partage-entre-site-et-bot
```

Édite `bot/.env` :
```env
DISCORD_BOT_TOKEN=TON_BOT_TOKEN
DISCORD_GUILD_ID=ID_DE_TON_SERVEUR
NEXT_PUBLIC_APP_URL=https://ton-domaine.com
BOT_WEBHOOK_SECRET=un-secret-partage-entre-site-et-bot
```

### 4. Base de données Supabase

Dans ton dashboard Supabase → **SQL Editor** → exécute le contenu de `supabase_schema.sql`

### 5. Discord — Configurer le bot

1. Va sur https://discord.com/developers/applications
2. Sélectionne ton application (`1493793870364934144`)
3. **Bot** → "Reset Token" → copie le token → mets-le dans `bot/.env`
4. **OAuth2 → Redirects** → ajoute : `https://ton-domaine.com/api/auth/callback/discord`
5. Active les **Privileged Gateway Intents** : Server Members, Message Content

### 6. Lancer le site

```bash
# Développement
npm run dev

# Production
npm run build
npm start
```

### 7. Lancer le bot

```bash
cd bot
node bot.js
```

---

## 🌐 Déploiement

### Option A — Vercel (recommandé pour le site)

```bash
npx vercel
```
Ajoute toutes les variables d'environnement dans le dashboard Vercel.

### Option B — VPS / Railway / Render

Le site peut tourner sur n'importe quelle plateforme Node.js.  
Le bot Discord tourne en process Node.js séparé (Railway, VPS, etc.)

---

## 🤖 Commandes du bot Discord

| Commande | Description |
|---|---|
| `/personnage voir` | Voir tes personnages |
| `/personnage créer` | Créer un nouveau personnage |
| `/personnage chercher [nom]` | Chercher un personnage |
| `/arbre` | Afficher un résumé de l'arbre + lien vers le site |
| `/lier [A] [relation] [B]` | *(Admin)* Lier deux personnages |
| `/admin role [user] [role]` | *(Admin)* Changer le rôle d'un utilisateur |
| `/admin stats` | *(Admin)* Statistiques du serveur |
| `/hotd` | Infos et lien vers le site |

---

## 🗂️ Structure du projet

```
hotd-rp/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── auth/[...nextauth]/   # Auth Discord OAuth
│   │   │   ├── characters/           # CRUD personnages
│   │   │   ├── relations/            # CRUD liens familiaux
│   │   │   ├── families/             # CRUD maisons
│   │   │   └── discord-bot/          # Webhook pour le bot
│   │   ├── login/                    # Page de connexion
│   │   ├── dashboard/                # Tableau de bord
│   │   ├── tree/                     # Arbre généalogique D3
│   │   └── admin/                    # Panneau admin
│   ├── lib/
│   │   └── supabase.ts               # Client Supabase
│   └── types/
│       └── index.ts                  # Types TypeScript
├── bot/
│   ├── bot.js                        # Bot Discord (discord.js)
│   └── package.json
├── supabase_schema.sql               # Schéma BDD à importer
├── .env.local                        # Variables d'environnement
└── README.md
```

---

## 🔐 Sécurité

- **Rotate tes clés Supabase** et Discord après ce partage
- Génère un `NEXTAUTH_SECRET` fort : `openssl rand -base64 32`
- Change le `BOT_WEBHOOK_SECRET` par quelque chose d'unique

---

## 🐉 Feu et Sang
