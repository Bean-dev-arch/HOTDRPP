const { Client, GatewayIntentBits, SlashCommandBuilder, REST, Routes, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js')

const BOT_TOKEN = process.env.DISCORD_BOT_TOKEN
const CLIENT_ID = '1493793870364934144'
const GUILD_ID = process.env.DISCORD_GUILD_ID
const API_URL = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'
const BOT_SECRET = process.env.BOT_WEBHOOK_SECRET || 'hotd-bot-secret'

// ============================================================
// Helper: call the web app API
// ============================================================
async function callAPI(action, discord_id, data = {}) {
  const res = await fetch(`${API_URL}/api/discord-bot`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-bot-secret': BOT_SECRET,
    },
    body: JSON.stringify({ action, discord_id, data }),
  })
  return res.json()
}

// ============================================================
// Colors for embeds
// ============================================================
const COLORS = {
  targaryen: 0x8B0000,
  gold: 0xFFD700,
  info: 0x5865F2,
  success: 0x57F287,
  error: 0xED4245,
  neutral: 0x2F3136,
}

// ============================================================
// Slash commands definitions
// ============================================================
const commands = [
  new SlashCommandBuilder()
    .setName('personnage')
    .setDescription('Gérer vos personnages HOTD RP')
    .addSubcommand(sub =>
      sub.setName('voir').setDescription('Voir vos personnages')
    )
    .addSubcommand(sub =>
      sub.setName('créer').setDescription('Créer un nouveau personnage')
        .addStringOption(opt => opt.setName('nom').setDescription('Nom du personnage').setRequired(true))
        .addStringOption(opt => opt.setName('maison').setDescription('Maison noble').setRequired(false)
          .addChoices(
            { name: 'Targaryen', value: 'targaryen' },
            { name: 'Velaryon', value: 'velaryon' },
            { name: 'Hightower', value: 'hightower' },
            { name: 'Lannister', value: 'lannister' },
            { name: 'Stark', value: 'stark' },
            { name: 'Baratheon', value: 'baratheon' },
            { name: 'Autre', value: 'autre' },
          ))
        .addStringOption(opt => opt.setName('titre').setDescription('Titre (Ser, Lord, Prince...)').setRequired(false))
        .addIntegerOption(opt => opt.setName('age').setDescription('Âge du personnage').setRequired(false))
        .addStringOption(opt => opt.setName('genre').setDescription('Genre').setRequired(false)
          .addChoices(
            { name: 'Masculin', value: 'male' },
            { name: 'Féminin', value: 'female' },
            { name: 'Autre', value: 'other' },
          ))
        .addStringOption(opt => opt.setName('description').setDescription('Description du personnage').setRequired(false))
    )
    .addSubcommand(sub =>
      sub.setName('chercher').setDescription('Chercher un personnage')
        .addStringOption(opt => opt.setName('nom').setDescription('Nom à chercher').setRequired(true))
    ),

  new SlashCommandBuilder()
    .setName('arbre')
    .setDescription('Afficher l\'arbre généalogique')
    .addStringOption(opt => opt.setName('maison').setDescription('Filtrer par maison').setRequired(false)),

  new SlashCommandBuilder()
    .setName('lier')
    .setDescription('[ADMIN] Lier deux personnages')
    .addStringOption(opt => opt.setName('personnage_a').setDescription('ID ou nom du personnage A').setRequired(true))
    .addStringOption(opt => opt.setName('personnage_b').setDescription('ID ou nom du personnage B').setRequired(true))
    .addStringOption(opt => opt.setName('relation').setDescription('Type de relation').setRequired(true)
      .addChoices(
        { name: 'Parent', value: 'parent' },
        { name: 'Enfant', value: 'child' },
        { name: 'Frère/Sœur', value: 'sibling' },
        { name: 'Époux/Épouse', value: 'spouse' },
        { name: 'Fiancé(e)', value: 'betrothed' },
        { name: 'Amant(e)', value: 'lover' },
        { name: 'Légitimisé', value: 'legitimized' },
        { name: 'Bâtard de', value: 'bastard_of' },
      )),

  new SlashCommandBuilder()
    .setName('admin')
    .setDescription('[ADMIN] Commandes d\'administration')
    .addSubcommand(sub =>
      sub.setName('role')
        .setDescription('Changer le rôle d\'un utilisateur')
        .addUserOption(opt => opt.setName('utilisateur').setDescription('Utilisateur Discord').setRequired(true))
        .addStringOption(opt => opt.setName('role').setDescription('Nouveau rôle').setRequired(true)
          .addChoices(
            { name: 'Membre', value: 'member' },
            { name: 'Modérateur', value: 'moderator' },
            { name: 'Admin', value: 'admin' },
          ))
    )
    .addSubcommand(sub =>
      sub.setName('stats').setDescription('Statistiques du serveur RP')
    ),

  new SlashCommandBuilder()
    .setName('hotd')
    .setDescription('Informations sur le serveur HOTD RP'),
]

// ============================================================
// Register commands
// ============================================================
async function registerCommands() {
  const rest = new REST({ version: '10' }).setToken(BOT_TOKEN)
  try {
    console.log('🐉 Enregistrement des commandes slash...')
    await rest.put(
      GUILD_ID
        ? Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID)
        : Routes.applicationCommands(CLIENT_ID),
      { body: commands.map(c => c.toJSON()) }
    )
    console.log('✅ Commandes enregistrées !')
  } catch (err) {
    console.error('❌ Erreur enregistrement commandes:', err)
  }
}

// ============================================================
// Helper: Character embed
// ============================================================
function characterEmbed(char) {
  const statusEmoji = { alive: '💚', dead: '💀', unknown: '❓', dragon: '🐉' }
  const genderEmoji = { male: '♂️', female: '♀️', other: '⚧️', unknown: '❓' }

  return new EmbedBuilder()
    .setTitle(`${char.title ? char.title + ' ' : ''}${char.name}`)
    .setColor(char.house?.color_primary ? parseInt(char.house.color_primary.replace('#', ''), 16) : COLORS.targaryen)
    .setThumbnail(char.avatar_url || null)
    .addFields(
      { name: 'Maison', value: char.house ? `${char.house.sigil || ''} ${char.house.name}` : 'Sans maison', inline: true },
      { name: 'Statut', value: `${statusEmoji[char.status] || '❓'} ${char.status}`, inline: true },
      { name: 'Genre', value: `${genderEmoji[char.gender] || '❓'} ${char.gender || 'Inconnu'}`, inline: true },
      ...(char.age ? [{ name: 'Âge', value: `${char.age} ans`, inline: true }] : []),
      ...(char.description ? [{ name: 'Description', value: char.description.substring(0, 500) }] : []),
    )
    .setFooter({ text: `ID: ${char.id}` })
    .setTimestamp()
}

// ============================================================
// Client
// ============================================================
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ],
})

client.once('ready', async () => {
  console.log(`🐉 Bot connecté en tant que ${client.user.tag}`)
  client.user.setActivity('Westeros', { type: 3 }) // WATCHING
  await registerCommands()
})

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isChatInputCommand()) return

  const { commandName, user } = interaction
  const discordId = user.id

  try {
    // ── /personnage ──────────────────────────────────────────
    if (commandName === 'personnage') {
      const sub = interaction.options.getSubcommand()

      if (sub === 'voir') {
        await interaction.deferReply({ ephemeral: true })
        const result = await callAPI('get_my_characters', discordId)

        if (!result.characters?.length) {
          return interaction.editReply({
            embeds: [new EmbedBuilder()
              .setColor(COLORS.neutral)
              .setTitle('🐉 Aucun personnage')
              .setDescription(`Tu n'as pas encore de personnage.\nUtilise \`/personnage créer\` ou connecte-toi sur **${API_URL}** pour en créer un !`)
            ]
          })
        }

        const embeds = result.characters.slice(0, 10).map(char => characterEmbed(char))
        return interaction.editReply({ embeds })
      }

      if (sub === 'créer') {
        await interaction.deferReply({ ephemeral: true })
        const nom = interaction.options.getString('nom')
        const maison = interaction.options.getString('maison')
        const titre = interaction.options.getString('titre')
        const age = interaction.options.getInteger('age')
        const genre = interaction.options.getString('genre')
        const description = interaction.options.getString('description')

        // Get house ID from name
        let house_id = null
        if (maison && maison !== 'autre') {
          const housesRes = await callAPI('get_tree', discordId)
          // We need houses — use a direct approach
        }

        const result = await callAPI('create_character', discordId, {
          name: nom,
          title: titre,
          age,
          gender: genre || 'unknown',
          description,
        })

        if (result.error) {
          return interaction.editReply({
            embeds: [new EmbedBuilder()
              .setColor(COLORS.error)
              .setTitle('❌ Erreur')
              .setDescription(result.error)
            ]
          })
        }

        return interaction.editReply({
          embeds: [
            new EmbedBuilder()
              .setColor(COLORS.success)
              .setTitle('✅ Personnage créé !')
              .setDescription(`**${nom}** a rejoint l'histoire de Westeros.`)
              .addFields(
                { name: 'ID', value: result.character.id, inline: true },
              )
              .setFooter({ text: `Complète son profil sur ${API_URL}` })
          ]
        })
      }

      if (sub === 'chercher') {
        await interaction.deferReply()
        const nom = interaction.options.getString('nom')
        const result = await callAPI('get_character', discordId, { name: nom })

        if (!result.character) {
          return interaction.editReply({
            embeds: [new EmbedBuilder()
              .setColor(COLORS.neutral)
              .setDescription(`Aucun personnage trouvé pour "${nom}"`)
            ]
          })
        }

        return interaction.editReply({ embeds: [characterEmbed(result.character)] })
      }
    }

    // ── /arbre ───────────────────────────────────────────────
    if (commandName === 'arbre') {
      await interaction.deferReply()
      const result = await callAPI('get_tree', discordId)
      const chars = result.characters || []
      const rels = result.relations || []

      const embed = new EmbedBuilder()
        .setColor(COLORS.targaryen)
        .setTitle('🐉 Arbre Généalogique des Sept Couronnes')
        .setDescription(`**${chars.length}** personnages · **${rels.length}** liens familiaux\n\nConsulte l'arbre complet sur le site :`)
        .addFields(
          ...chars.slice(0, 10).map(c => ({
            name: `${c.title ? c.title + ' ' : ''}${c.name}`,
            value: c.house ? `${c.house.sigil || '🏰'} ${c.house.name}` : 'Sans maison',
            inline: true,
          }))
        )
        .setFooter({ text: `Voir l'arbre complet sur ${API_URL}` })

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setLabel('Voir l\'arbre complet')
          .setStyle(ButtonStyle.Link)
          .setURL(API_URL)
          .setEmoji('🐉')
      )

      return interaction.editReply({ embeds: [embed], components: [row] })
    }

    // ── /lier ────────────────────────────────────────────────
    if (commandName === 'lier') {
      await interaction.deferReply({ ephemeral: true })

      const charA = interaction.options.getString('personnage_a')
      const charB = interaction.options.getString('personnage_b')
      const relType = interaction.options.getString('relation')

      // Resolve characters
      const resA = await callAPI('get_character', discordId, { name: charA })
      const resB = await callAPI('get_character', discordId, { name: charB })

      if (!resA.character) return interaction.editReply(`❌ Personnage "${charA}" introuvable.`)
      if (!resB.character) return interaction.editReply(`❌ Personnage "${charB}" introuvable.`)

      const result = await callAPI('link_characters', discordId, {
        character_a_id: resA.character.id,
        character_b_id: resB.character.id,
        relation_type: relType,
      })

      if (result.error) {
        return interaction.editReply({
          embeds: [new EmbedBuilder().setColor(COLORS.error).setDescription(`❌ ${result.error}`)]
        })
      }

      return interaction.editReply({
        embeds: [new EmbedBuilder()
          .setColor(COLORS.success)
          .setTitle('✅ Lien créé !')
          .setDescription(`**${resA.character.name}** ↔ **${resB.character.name}**\nRelation : **${relType}**`)
        ]
      })
    }

    // ── /admin ───────────────────────────────────────────────
    if (commandName === 'admin') {
      const sub = interaction.options.getSubcommand()

      if (sub === 'role') {
        await interaction.deferReply({ ephemeral: true })
        const targetUser = interaction.options.getUser('utilisateur')
        const newRole = interaction.options.getString('role')

        const result = await callAPI('set_role', discordId, {
          target_discord_id: targetUser.id,
          role: newRole,
        })

        if (result.error) return interaction.editReply(`❌ ${result.error}`)
        return interaction.editReply(`✅ Rôle de <@${targetUser.id}> mis à jour : **${newRole}**`)
      }

      if (sub === 'stats') {
        await interaction.deferReply({ ephemeral: true })
        const result = await callAPI('get_tree', discordId)
        const embed = new EmbedBuilder()
          .setColor(COLORS.gold)
          .setTitle('📊 Statistiques HOTD RP')
          .addFields(
            { name: 'Personnages', value: `${result.characters?.length || 0}`, inline: true },
            { name: 'Relations', value: `${result.relations?.length || 0}`, inline: true },
          )
        return interaction.editReply({ embeds: [embed] })
      }
    }

    // ── /hotd ────────────────────────────────────────────────
    if (commandName === 'hotd') {
      const embed = new EmbedBuilder()
        .setColor(COLORS.targaryen)
        .setTitle('🐉 HOTD RP — Arbre Généalogique des Sept Couronnes')
        .setDescription('Bienvenue dans l\'univers collaboratif de House of the Dragon RP !')
        .addFields(
          { name: '📜 Commandes', value: '`/personnage voir` · `/personnage créer` · `/arbre` · `/chercher`' },
          { name: '🌐 Site web', value: API_URL },
          { name: '🔑 Connexion', value: 'Connecte-toi avec Discord sur le site pour accéder à toutes les fonctionnalités' },
        )
        .setFooter({ text: 'Feu et Sang — HOTD RP' })

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setLabel('Accéder au site')
          .setStyle(ButtonStyle.Link)
          .setURL(API_URL)
          .setEmoji('🐉')
      )

      return interaction.reply({ embeds: [embed], components: [row] })
    }

  } catch (err) {
    console.error(`❌ Erreur commande ${commandName}:`, err)
    const msg = { content: '❌ Une erreur est survenue. Réessaie plus tard.', ephemeral: true }
    if (interaction.deferred) interaction.editReply(msg)
    else interaction.reply(msg)
  }
})

client.login(BOT_TOKEN)
