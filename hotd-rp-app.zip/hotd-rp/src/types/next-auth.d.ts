import 'next-auth'

declare module 'next-auth' {
  interface Session {
    user: {
      name?: string | null
      email?: string | null
      image?: string | null
      discordId: string
      avatar: string
      role: string
      userId: string
    }
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    discordId?: string
    avatar?: string
    role?: string
    userId?: string
  }
}
