export type UserRole = 'member' | 'moderator' | 'admin'
export type CharacterStatus = 'alive' | 'dead' | 'unknown' | 'dragon'
export type RelationType = 'parent' | 'child' | 'sibling' | 'spouse' | 'betrothed' | 'lover' | 'legitimized' | 'bastard_of' | 'dragon_rider'

export interface User {
  id: string
  discord_id: string
  username: string
  discriminator?: string
  avatar?: string
  email?: string
  role: UserRole
  created_at: string
  last_login: string
}

export interface House {
  id: string
  name: string
  sigil?: string
  words?: string
  description?: string
  region?: string
  color_primary: string
  color_secondary: string
  is_extinct: boolean
  created_at: string
}

export interface Character {
  id: string
  name: string
  house_id?: string
  house?: House
  title?: string
  age?: number
  gender?: 'male' | 'female' | 'other' | 'unknown'
  status: CharacterStatus
  description?: string
  avatar_url?: string
  is_dragon: boolean
  dragon_name?: string
  player_discord_id?: string
  player_id?: string
  player?: User
  is_canon: boolean
  is_public: boolean
  created_at: string
  updated_at: string
}

export interface Relation {
  id: string
  character_a_id: string
  character_b_id: string
  character_a?: Character
  character_b?: Character
  relation_type: RelationType
  is_secret: boolean
  notes?: string
  created_at: string
}

export interface Event {
  id: string
  title: string
  description?: string
  event_date?: string
  event_type: 'birth' | 'death' | 'marriage' | 'war' | 'rp' | 'announcement'
  characters_involved: string[]
  created_at: string
}

export interface TreeNode {
  id: string
  name: string
  title?: string
  house?: string
  houseColor?: string
  avatar?: string
  status: CharacterStatus
  is_dragon: boolean
  x?: number
  y?: number
  children?: TreeNode[]
}

export interface TreeLink {
  source: string
  target: string
  type: RelationType
}
