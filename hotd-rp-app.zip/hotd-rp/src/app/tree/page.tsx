'use client'
import { useEffect, useRef, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import * as d3 from 'd3'
import Link from 'next/link'
import { Character, Relation, House } from '@/types'

interface NodeData extends d3.SimulationNodeDatum {
  id: string
  name: string
  title?: string
  status: string
  house?: { name: string; color_primary: string; sigil?: string }
  avatar_url?: string
  is_dragon: boolean
}

interface LinkData {
  source: string | NodeData
  target: string | NodeData
  relation_type: string
}

const REL_COLORS: Record<string, string> = {
  parent: '#e8c070',
  child: '#e8c070',
  sibling: '#86efac',
  spouse: '#f9a8d4',
  betrothed: '#fdba74',
  lover: '#f472b6',
  bastard_of: '#94a3b8',
  legitimized: '#a78bfa',
  dragon_rider: '#fb923c',
}

export default function TreePage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const svgRef = useRef<SVGSVGElement>(null)
  const [characters, setCharacters] = useState<Character[]>([])
  const [relations, setRelations] = useState<Relation[]>([])
  const [houses, setHouses] = useState<House[]>([])
  const [selectedChar, setSelectedChar] = useState<Character | null>(null)
  const [filterHouse, setFilterHouse] = useState('')
  const [loading, setLoading] = useState(true)
  const [showAddRelation, setShowAddRelation] = useState(false)
  const isAdmin = ['admin', 'moderator'].includes(session?.user?.role || '')

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login')
  }, [status, router])

  useEffect(() => {
    if (status === 'authenticated') fetchData()
  }, [status])

  async function fetchData() {
    setLoading(true)
    const [charsRes, relsRes, housesRes] = await Promise.all([
      fetch('/api/characters'),
      fetch('/api/relations'),
      fetch('/api/families'),
    ])
    const [charsData, relsData, housesData] = await Promise.all([
      charsRes.json(), relsRes.json(), housesRes.json()
    ])
    setCharacters(Array.isArray(charsData) ? charsData : [])
    setRelations(Array.isArray(relsData) ? relsData : [])
    setHouses(Array.isArray(housesData) ? housesData : [])
    setLoading(false)
  }

  useEffect(() => {
    if (loading || !svgRef.current || characters.length === 0) return
    renderTree()
  }, [characters, relations, filterHouse, loading])

  function renderTree() {
    const svg = d3.select(svgRef.current!)
    svg.selectAll('*').remove()

    const width = svgRef.current!.clientWidth || 900
    const height = svgRef.current!.clientHeight || 700

    svg.attr('viewBox', `0 0 ${width} ${height}`)

    const g = svg.append('g')

    // Zoom
    const zoom = d3.zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.1, 4])
      .on('zoom', e => g.attr('transform', e.transform))
    svg.call(zoom)

    // Filter by house
    const filteredChars = filterHouse
      ? characters.filter(c => c.house_id === filterHouse || c.house?.name === filterHouse)
      : characters

    const nodeIds = new Set(filteredChars.map(c => c.id))
    const filteredRels = relations.filter(r =>
      nodeIds.has(r.character_a_id) && nodeIds.has(r.character_b_id)
    )

    const nodes: NodeData[] = filteredChars.map(c => ({
      id: c.id,
      name: c.name,
      title: c.title,
      status: c.status,
      house: c.house as any,
      avatar_url: c.avatar_url,
      is_dragon: c.is_dragon,
    }))

    const links: LinkData[] = filteredRels.map(r => ({
      source: r.character_a_id,
      target: r.character_b_id,
      relation_type: r.relation_type,
    }))

    // Simulation
    const sim = d3.forceSimulation<NodeData>(nodes)
      .force('link', d3.forceLink<NodeData, LinkData>(links).id(d => d.id).distance(120))
      .force('charge', d3.forceManyBody().strength(-300))
      .force('center', d3.forceCenter(width / 2, height / 2))
      .force('collision', d3.forceCollide(55))

    // Defs: arrow marker + clip paths
    const defs = svg.append('defs')
    defs.append('marker')
      .attr('id', 'arrow')
      .attr('viewBox', '0 -5 10 10')
      .attr('refX', 30)
      .attr('markerWidth', 6)
      .attr('markerHeight', 6)
      .attr('orient', 'auto')
      .append('path')
      .attr('d', 'M0,-5L10,0L0,5')
      .attr('fill', 'rgba(200,160,100,0.5)')

    // Links
    const link = g.append('g').selectAll('line')
      .data(links).join('line')
      .attr('stroke', d => REL_COLORS[d.relation_type] || '#888')
      .attr('stroke-width', 1.5)
      .attr('stroke-opacity', 0.6)
      .attr('stroke-dasharray', d => ['bastard_of', 'lover', 'betrothed'].includes(d.relation_type) ? '5,4' : 'none')

    // Link labels
    const linkLabel = g.append('g').selectAll('text')
      .data(links).join('text')
      .attr('font-size', 10)
      .attr('fill', d => REL_COLORS[d.relation_type] || '#888')
      .attr('opacity', 0.7)
      .attr('text-anchor', 'middle')
      .text(d => d.relation_type.replace('_', ' '))

    // Node groups
    const node = g.append('g').selectAll('g')
      .data(nodes).join('g')
      .attr('cursor', 'pointer')
      .call(d3.drag<SVGGElement, NodeData>()
        .on('start', (e, d) => { if (!e.active) sim.alphaTarget(0.3).restart(); d.fx = d.x; d.fy = d.y })
        .on('drag', (e, d) => { d.fx = e.x; d.fy = e.y })
        .on('end', (e, d) => { if (!e.active) sim.alphaTarget(0); d.fx = null; d.fy = null })
      )
      .on('click', (e, d) => {
        const char = characters.find(c => c.id === d.id)
        if (char) setSelectedChar(char)
      })

    // Node circle background
    node.append('circle')
      .attr('r', 30)
      .attr('fill', d => {
        if (d.status === 'dead') return '#1a0808'
        return d.house?.color_primary || '#3d0a00'
      })
      .attr('stroke', d => d.house?.color_primary || '#8B0000')
      .attr('stroke-width', d => d.is_dragon ? 3 : 1.5)
      .attr('stroke-dasharray', d => d.is_dragon ? '4,2' : 'none')
      .attr('opacity', d => d.status === 'dead' ? 0.6 : 1)

    // Node text (initials or emoji)
    node.append('text')
      .attr('text-anchor', 'middle')
      .attr('dominant-baseline', 'middle')
      .attr('font-size', d => d.is_dragon ? 22 : 16)
      .attr('fill', '#FFD700')
      .text(d => d.is_dragon ? '🐉' : d.name.charAt(0))

    // Status indicator
    node.filter(d => d.status === 'dead')
      .append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', -28)
      .attr('font-size', 12)
      .text('✕')
      .attr('fill', '#ef4444')

    // Name label
    node.append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', 42)
      .attr('font-size', 11)
      .attr('font-family', 'Cinzel, serif')
      .attr('fill', '#e8c070')
      .text(d => d.name.length > 14 ? d.name.substring(0, 13) + '…' : d.name)

    // House sigil
    node.filter(d => !!d.house?.sigil)
      .append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', -32)
      .attr('font-size', 11)
      .text(d => d.house?.sigil || '')

    sim.on('tick', () => {
      link
        .attr('x1', d => (d.source as NodeData).x!)
        .attr('y1', d => (d.source as NodeData).y!)
        .attr('x2', d => (d.target as NodeData).x!)
        .attr('y2', d => (d.target as NodeData).y!)

      linkLabel
        .attr('x', d => ((d.source as NodeData).x! + (d.target as NodeData).x!) / 2)
        .attr('y', d => ((d.source as NodeData).y! + (d.target as NodeData).y!) / 2 - 6)

      node.attr('transform', d => `translate(${d.x},${d.y})`)
    })
  }

  return (
    <div style={styles.root}>
      {/* Nav */}
      <nav style={styles.nav}>
        <Link href="/dashboard" style={styles.back}>← Tableau de bord</Link>
        <span style={styles.navTitle}>🌳 Arbre Généalogique des Sept Couronnes</span>
        <div style={styles.navActions}>
          <select style={styles.select} value={filterHouse} onChange={e => setFilterHouse(e.target.value)}>
            <option value="">Toutes les maisons</option>
            {houses.map(h => <option key={h.id} value={h.name}>{h.sigil} {h.name}</option>)}
          </select>
          {isAdmin && (
            <button style={styles.addBtn} onClick={() => setShowAddRelation(true)}>+ Lien familial</button>
          )}
        </div>
      </nav>

      {/* Legend */}
      <div style={styles.legend}>
        {Object.entries(REL_COLORS).map(([type, color]) => (
          <span key={type} style={styles.legendItem}>
            <span style={{ ...styles.legendDot, background: color }} />
            {type.replace('_', ' ')}
          </span>
        ))}
      </div>

      {/* Tree SVG */}
      <div style={styles.treeContainer}>
        {loading ? (
          <div style={styles.loading}>🐉 Chargement de l'arbre...</div>
        ) : characters.length === 0 ? (
          <div style={styles.loading}>Aucun personnage. <Link href="/dashboard">Créez-en un !</Link></div>
        ) : (
          <svg ref={svgRef} style={styles.svg} />
        )}
      </div>

      {/* Character detail panel */}
      {selectedChar && (
        <div style={styles.panel}>
          <button onClick={() => setSelectedChar(null)} style={styles.closeBtn}>✕</button>
          <div style={{ ...styles.panelAvatar, background: selectedChar.house?.color_primary || '#8B0000' }}>
            {selectedChar.avatar_url
              ? <img src={selectedChar.avatar_url} style={{ width: '100%', height: '100%', borderRadius: '50%', objectFit: 'cover' }} alt="" />
              : selectedChar.name[0]
            }
          </div>
          <h3 style={styles.panelName}>{selectedChar.title ? `${selectedChar.title} ` : ''}{selectedChar.name}</h3>
          <p style={styles.panelHouse}>{selectedChar.house?.sigil} {selectedChar.house?.name || 'Sans maison'}</p>
          <div style={styles.panelStats}>
            {selectedChar.age && <span>Âge : {selectedChar.age} ans</span>}
            <span style={{ color: selectedChar.status === 'alive' ? '#4ade80' : '#ef4444' }}>● {selectedChar.status}</span>
          </div>
          {selectedChar.description && <p style={styles.panelDesc}>{selectedChar.description}</p>}
          {selectedChar.player_discord_id && (
            <p style={styles.panelPlayer}>👤 Joué par <strong>{selectedChar.player?.username || 'un joueur'}</strong></p>
          )}
          {/* Relations */}
          <div style={styles.panelRelations}>
            <p style={styles.panelRelTitle}>Liens familiaux :</p>
            {relations
              .filter(r => r.character_a_id === selectedChar.id || r.character_b_id === selectedChar.id)
              .map(r => {
                const other = r.character_a_id === selectedChar.id ? r.character_b : r.character_a
                return (
                  <div key={r.id} style={styles.panelRel}>
                    <span style={{ color: REL_COLORS[r.relation_type] || '#888', fontSize: 11 }}>
                      {r.relation_type.replace('_', ' ')}
                    </span>
                    <span style={{ color: '#e8c070' }}>
                      {(other as any)?.name || '?'}
                    </span>
                  </div>
                )
              })}
          </div>
        </div>
      )}

      {/* Add relation modal */}
      {showAddRelation && isAdmin && (
        <AddRelationModal
          characters={characters}
          onClose={() => setShowAddRelation(false)}
          onCreated={() => { setShowAddRelation(false); fetchData() }}
        />
      )}
    </div>
  )
}

function AddRelationModal({ characters, onClose, onCreated }: {
  characters: Character[]; onClose: () => void; onCreated: () => void
}) {
  const [form, setForm] = useState({ character_a_id: '', character_b_id: '', relation_type: 'parent', notes: '' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function submit() {
    if (!form.character_a_id || !form.character_b_id) return setError('Sélectionne deux personnages')
    setLoading(true)
    const res = await fetch('/api/relations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    })
    const data = await res.json()
    setLoading(false)
    if (data.error) return setError(data.error)
    onCreated()
  }

  return (
    <div style={styles.modalOverlay} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={styles.modal}>
        <h2 style={{ fontFamily: 'Cinzel, serif', color: '#e8c070', marginBottom: '1.5rem', textAlign: 'center' }}>⚔️ Lier des personnages</h2>
        {error && <p style={{ color: '#ef4444', marginBottom: 12 }}>{error}</p>}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <label style={styles.label}>Personnage A</label>
          <select style={styles.input} value={form.character_a_id} onChange={e => setForm({...form, character_a_id: e.target.value})}>
            <option value="">Choisir...</option>
            {characters.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <label style={styles.label}>Relation (A → B)</label>
          <select style={styles.input} value={form.relation_type} onChange={e => setForm({...form, relation_type: e.target.value})}>
            {Object.keys(REL_COLORS).map(r => <option key={r} value={r}>{r.replace('_', ' ')}</option>)}
          </select>
          <label style={styles.label}>Personnage B</label>
          <select style={styles.input} value={form.character_b_id} onChange={e => setForm({...form, character_b_id: e.target.value})}>
            <option value="">Choisir...</option>
            {characters.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <label style={styles.label}>Notes (optionnel)</label>
          <input style={styles.input} value={form.notes} onChange={e => setForm({...form, notes: e.target.value})} placeholder="Notes sur ce lien..." />
        </div>
        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: '1.5rem' }}>
          <button onClick={onClose} style={styles.cancelBtn}>Annuler</button>
          <button onClick={submit} disabled={loading} style={styles.submitBtn}>{loading ? '...' : '✅ Créer le lien'}</button>
        </div>
      </div>
    </div>
  )
}

const styles: Record<string, React.CSSProperties> = {
  root: { height: '100vh', display: 'flex', flexDirection: 'column', background: '#0a0608', color: '#e8d5b0', fontFamily: "'Crimson Text', Georgia, serif", overflow: 'hidden' },
  nav: { display: 'flex', alignItems: 'center', padding: '0.6rem 1.5rem', background: 'rgba(10,4,8,0.98)', borderBottom: '1px solid rgba(180,80,20,0.3)', gap: 16, flexWrap: 'wrap' },
  back: { color: 'rgba(200,160,100,0.7)', textDecoration: 'none', fontFamily: 'Cinzel, serif', fontSize: '0.8rem' },
  navTitle: { flex: 1, fontFamily: 'Cinzel, serif', color: '#e8c070', fontSize: '0.95rem', letterSpacing: '0.05em' },
  navActions: { display: 'flex', gap: 8, alignItems: 'center' },
  select: { background: 'rgba(20,8,12,0.8)', border: '1px solid rgba(180,80,20,0.3)', borderRadius: 3, padding: '5px 10px', color: '#e8d5b0', fontFamily: "'Crimson Text', Georgia, serif", fontSize: '0.9rem' },
  addBtn: { background: '#8B0000', border: 'none', color: '#FFD700', padding: '6px 14px', cursor: 'pointer', borderRadius: 3, fontFamily: 'Cinzel, serif', fontSize: '0.8rem' },
  legend: { display: 'flex', gap: 12, padding: '6px 1.5rem', background: 'rgba(10,4,8,0.9)', borderBottom: '1px solid rgba(180,80,20,0.1)', flexWrap: 'wrap' },
  legendItem: { display: 'flex', alignItems: 'center', gap: 4, fontSize: '0.72rem', color: 'rgba(200,160,100,0.6)' },
  legendDot: { width: 8, height: 8, borderRadius: '50%', flexShrink: 0 },
  treeContainer: { flex: 1, position: 'relative', overflow: 'hidden' },
  svg: { width: '100%', height: '100%', display: 'block' },
  loading: { display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', color: '#e8c070', fontSize: '1.2rem', gap: 8 },
  panel: { position: 'absolute', right: 16, top: 80, width: 280, background: 'rgba(15,6,10,0.97)', border: '1px solid rgba(180,80,20,0.35)', borderRadius: 6, padding: '1.25rem', zIndex: 100 },
  closeBtn: { position: 'absolute', top: 8, right: 10, background: 'transparent', border: 'none', color: 'rgba(200,160,100,0.5)', cursor: 'pointer', fontSize: '1rem' },
  panelAvatar: { width: 56, height: 56, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#FFD700', fontSize: '1.5rem', fontWeight: 700, margin: '0 auto 0.75rem', border: '2px solid rgba(200,100,30,0.5)' },
  panelName: { fontFamily: 'Cinzel, serif', color: '#e8c070', textAlign: 'center', fontSize: '1rem', marginBottom: 4 },
  panelHouse: { textAlign: 'center', color: 'rgba(200,160,100,0.6)', marginBottom: 8, fontSize: '0.85rem' },
  panelStats: { display: 'flex', gap: 12, justifyContent: 'center', marginBottom: 8, fontSize: '0.8rem', color: 'rgba(200,160,100,0.7)' },
  panelDesc: { fontSize: '0.85rem', color: 'rgba(200,160,100,0.7)', lineHeight: 1.5, borderTop: '1px solid rgba(180,80,20,0.15)', paddingTop: 8, marginTop: 8 },
  panelPlayer: { fontSize: '0.82rem', color: 'rgba(200,160,100,0.5)', marginTop: 6 },
  panelRelations: { marginTop: 10, borderTop: '1px solid rgba(180,80,20,0.15)', paddingTop: 8 },
  panelRelTitle: { fontSize: '0.75rem', fontFamily: 'Cinzel, serif', color: 'rgba(200,160,100,0.5)', marginBottom: 6, letterSpacing: '0.05em' },
  panelRel: { display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', padding: '2px 0' },
  modalOverlay: { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: '1rem' },
  modal: { background: '#0f0608', border: '1px solid rgba(180,80,20,0.4)', borderRadius: 6, padding: '2rem', width: '100%', maxWidth: 460 },
  label: { fontSize: '0.8rem', color: 'rgba(200,160,100,0.7)', fontFamily: 'Cinzel, serif', letterSpacing: '0.05em' },
  input: { background: 'rgba(20,8,12,0.8)', border: '1px solid rgba(180,80,20,0.3)', borderRadius: 3, padding: '8px 12px', color: '#e8d5b0', fontSize: '0.95rem', fontFamily: "'Crimson Text', Georgia, serif", width: '100%' },
  cancelBtn: { background: 'transparent', border: '1px solid rgba(180,80,20,0.3)', color: 'rgba(200,160,100,0.6)', padding: '8px 18px', cursor: 'pointer', borderRadius: 3, fontFamily: 'Cinzel, serif', fontSize: '0.85rem' },
  submitBtn: { background: '#8B0000', border: 'none', color: '#FFD700', padding: '8px 18px', cursor: 'pointer', borderRadius: 3, fontFamily: 'Cinzel, serif', fontSize: '0.85rem' },
}
