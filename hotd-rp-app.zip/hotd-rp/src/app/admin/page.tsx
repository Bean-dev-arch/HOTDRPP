'use client'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Character, House, User } from '@/types'

export default function AdminPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [tab, setTab] = useState<'characters' | 'houses' | 'users' | 'relations'>('characters')
  const [characters, setCharacters] = useState<Character[]>([])
  const [houses, setHouses] = useState<House[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login')
    if (status === 'authenticated' && !['admin', 'moderator'].includes(session?.user?.role || '')) {
      router.push('/dashboard')
    }
  }, [status, session, router])

  useEffect(() => {
    if (status === 'authenticated') fetchAll()
  }, [status])

  async function fetchAll() {
    setLoading(true)
    const [charsRes, housesRes] = await Promise.all([
      fetch('/api/characters'),
      fetch('/api/families'),
    ])
    setCharacters(await charsRes.json())
    setHouses(await housesRes.json())
    setLoading(false)
  }

  async function deleteCharacter(id: string) {
    if (!confirm('Supprimer ce personnage ?')) return
    await fetch(`/api/characters?id=${id}`, { method: 'DELETE' })
    fetchAll()
  }

  async function toggleCharStatus(char: Character) {
    const newStatus = char.status === 'alive' ? 'dead' : 'alive'
    await fetch('/api/characters', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: char.id, status: newStatus }),
    })
    fetchAll()
  }

  if (status === 'loading' || loading) {
    return <div style={styles.loading}>🐉 Chargement du panneau admin...</div>
  }

  return (
    <div style={styles.root}>
      <nav style={styles.nav}>
        <Link href="/dashboard" style={styles.back}>← Dashboard</Link>
        <span style={styles.navTitle}>⚔️ Administration HOTD RP</span>
        <span style={styles.roleBadge}>{session?.user?.role}</span>
      </nav>

      {/* Stats */}
      <div style={styles.statsGrid}>
        <div style={styles.statCard}>
          <div style={styles.statNum}>{characters.length}</div>
          <div style={styles.statLabel}>Personnages</div>
        </div>
        <div style={styles.statCard}>
          <div style={styles.statNum}>{characters.filter(c => c.status === 'alive').length}</div>
          <div style={styles.statLabel}>En vie</div>
        </div>
        <div style={styles.statCard}>
          <div style={styles.statNum}>{houses.length}</div>
          <div style={styles.statLabel}>Maisons</div>
        </div>
        <div style={styles.statCard}>
          <div style={styles.statNum}>{characters.filter(c => c.player_discord_id).length}</div>
          <div style={styles.statLabel}>Joués</div>
        </div>
      </div>

      {/* Tabs */}
      <div style={styles.tabs}>
        {(['characters', 'houses'] as const).map(t => (
          <button key={t} style={{ ...styles.tab, ...(tab === t ? styles.tabActive : {}) }} onClick={() => setTab(t)}>
            {{ characters: '⚔️ Personnages', houses: '🛡️ Maisons' }[t]}
          </button>
        ))}
      </div>

      <div style={styles.content}>
        {tab === 'characters' && (
          <div>
            <table style={styles.table}>
              <thead>
                <tr>
                  {['Nom', 'Maison', 'Statut', 'Joueur', 'Actions'].map(h => (
                    <th key={h} style={styles.th}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {characters.map(char => (
                  <tr key={char.id} style={styles.tr}>
                    <td style={styles.td}>
                      <strong style={{ color: '#e8c070', fontFamily: 'Cinzel, serif' }}>{char.title ? `${char.title} ` : ''}{char.name}</strong>
                    </td>
                    <td style={styles.td}>{char.house?.sigil} {char.house?.name || '—'}</td>
                    <td style={styles.td}>
                      <span style={{ color: char.status === 'alive' ? '#4ade80' : '#ef4444' }}>● {char.status}</span>
                    </td>
                    <td style={styles.td} title={char.player_discord_id || ''}>
                      {char.player_discord_id ? `@${char.player_discord_id.substring(0, 8)}…` : '—'}
                    </td>
                    <td style={styles.td}>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button onClick={() => toggleCharStatus(char)} style={styles.actionBtn}>
                          {char.status === 'alive' ? '💀 Tuer' : '💚 Ressusciter'}
                        </button>
                        <button onClick={() => deleteCharacter(char.id)} style={{ ...styles.actionBtn, color: '#ef4444', borderColor: 'rgba(239,68,68,0.3)' }}>
                          🗑️ Supprimer
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {tab === 'houses' && (
          <div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 16 }}>
              {houses.map(house => (
                <div key={house.id} style={{ ...styles.houseCard, borderColor: house.color_primary }}>
                  <span style={{ fontSize: 36 }}>{house.sigil || '🏰'}</span>
                  <h3 style={{ fontFamily: 'Cinzel, serif', color: house.color_primary, marginBottom: 4 }}>{house.name}</h3>
                  <p style={{ fontSize: '0.8rem', color: 'rgba(200,160,100,0.6)', fontStyle: 'italic' }}>"{house.words}"</p>
                  <p style={{ fontSize: '0.8rem', color: 'rgba(200,160,100,0.5)', marginTop: 4 }}>{house.region}</p>
                  <p style={{ fontSize: '0.75rem', color: 'rgba(200,160,100,0.4)', marginTop: 6 }}>
                    {characters.filter(c => c.house_id === house.id).length} personnages
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

const styles: Record<string, React.CSSProperties> = {
  root: { minHeight: '100vh', background: '#0a0608', color: '#e8d5b0', fontFamily: "'Crimson Text', Georgia, serif" },
  loading: { display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', color: '#e8c070', fontSize: '1.2rem', background: '#0a0608' },
  nav: { display: 'flex', alignItems: 'center', padding: '0.75rem 2rem', background: 'rgba(10,4,8,0.98)', borderBottom: '1px solid rgba(180,80,20,0.3)', gap: 16 },
  back: { color: 'rgba(200,160,100,0.7)', textDecoration: 'none', fontFamily: 'Cinzel, serif', fontSize: '0.8rem' },
  navTitle: { flex: 1, fontFamily: 'Cinzel, serif', color: '#e8c070', fontSize: '1rem', letterSpacing: '0.08em' },
  roleBadge: { background: '#8B0000', color: '#FFD700', padding: '3px 10px', borderRadius: 3, fontSize: '0.75rem', fontFamily: 'Cinzel, serif', textTransform: 'uppercase', letterSpacing: '0.05em' },
  statsGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: 16, padding: '1.5rem 2rem' },
  statCard: { background: 'rgba(15,6,10,0.8)', border: '1px solid rgba(180,80,20,0.2)', borderRadius: 6, padding: '1rem', textAlign: 'center' },
  statNum: { fontFamily: 'Cinzel, serif', fontSize: '2rem', color: '#FFD700', fontWeight: 700 },
  statLabel: { fontSize: '0.8rem', color: 'rgba(200,160,100,0.6)', marginTop: 4, letterSpacing: '0.05em' },
  tabs: { display: 'flex', gap: 0, padding: '0 2rem', borderBottom: '1px solid rgba(180,80,20,0.2)' },
  tab: { background: 'transparent', border: 'none', borderBottom: '2px solid transparent', padding: '0.75rem 1.25rem', color: 'rgba(200,160,100,0.5)', cursor: 'pointer', fontFamily: 'Cinzel, serif', fontSize: '0.85rem', transition: 'all 0.15s' },
  tabActive: { borderBottomColor: '#8B0000', color: '#e8c070' },
  content: { padding: '1.5rem 2rem' },
  table: { width: '100%', borderCollapse: 'collapse' },
  th: { textAlign: 'left', padding: '8px 12px', borderBottom: '1px solid rgba(180,80,20,0.3)', fontFamily: 'Cinzel, serif', fontSize: '0.75rem', color: 'rgba(200,160,100,0.5)', letterSpacing: '0.08em', textTransform: 'uppercase' },
  tr: { borderBottom: '1px solid rgba(180,80,20,0.1)' },
  td: { padding: '10px 12px', fontSize: '0.9rem' },
  actionBtn: { background: 'transparent', border: '1px solid rgba(180,80,20,0.3)', color: 'rgba(200,160,100,0.7)', padding: '4px 10px', cursor: 'pointer', borderRadius: 3, fontSize: '0.78rem', fontFamily: 'Cinzel, serif' },
  houseCard: { background: 'rgba(15,6,10,0.8)', border: '1px solid', borderRadius: 6, padding: '1.25rem', textAlign: 'center' },
}
