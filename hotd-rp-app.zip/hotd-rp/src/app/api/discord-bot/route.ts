import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

// This endpoint is called by the Discord bot
// Secured by a shared secret
const BOT_SECRET = process.env.BOT_WEBHOOK_SECRET || 'hotd-bot-secret'

export async function POST(req: NextRequest) {
  const authHeader = req.headers.get('x-bot-secret')
  if (authHeader !== BOT_SECRET) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const body = await req.json()
  const { action, discord_id, data } = body

  try {
    switch (action) {
      case 'get_my_characters': {
        const { data: chars } = await supabaseAdmin
          .from('characters')
          .select('*, house:houses(name, sigil)')
          .eq('player_discord_id', discord_id)
        return NextResponse.json({ characters: chars })
      }

      case 'create_character': {
        // Check user exists
        const { data: user } = await supabaseAdmin
          .from('users')
          .select('id, role')
          .eq('discord_id', discord_id)
          .single()

        if (!user) return NextResponse.json({ error: 'Connecte-toi via le site web d\'abord !' })

        const { data: char, error } = await supabaseAdmin
          .from('characters')
          .insert({
            name: data.name,
            house_id: data.house_id,
            title: data.title,
            age: data.age,
            gender: data.gender,
            description: data.description,
            player_discord_id: discord_id,
            player_id: user.id,
            created_by: user.id,
          })
          .select('*, house:houses(name, sigil)')
          .single()

        if (error) return NextResponse.json({ error: error.message })
        
        // Log
        await supabaseAdmin.from('bot_logs').insert({
          discord_id, command: 'create_character', params: data, result: char.id, success: true
        })
        
        return NextResponse.json({ character: char, success: true })
      }

      case 'get_character': {
        const { data: char } = await supabaseAdmin
          .from('characters')
          .select('*, house:houses(*)')
          .ilike('name', `%${data.name}%`)
          .limit(1)
          .single()
        return NextResponse.json({ character: char })
      }

      case 'link_characters': {
        const { data: user } = await supabaseAdmin
          .from('users')
          .select('id, role')
          .eq('discord_id', discord_id)
          .single()

        if (!user || !['admin', 'moderator'].includes(user.role)) {
          return NextResponse.json({ error: 'Permission refusée. Seuls les admins peuvent lier des personnages.' })
        }

        const { error } = await supabaseAdmin.from('relations').insert({
          character_a_id: data.character_a_id,
          character_b_id: data.character_b_id,
          relation_type: data.relation_type,
          notes: data.notes,
          created_by: user.id,
        })

        if (error) return NextResponse.json({ error: error.message })
        return NextResponse.json({ success: true })
      }

      case 'get_tree': {
        const { data: characters } = await supabaseAdmin
          .from('characters')
          .select('id, name, title, status, house:houses(name, color_primary, sigil)')
          .limit(50)

        const { data: relations } = await supabaseAdmin
          .from('relations')
          .select('character_a_id, character_b_id, relation_type')
          .eq('is_secret', false)

        return NextResponse.json({ characters, relations })
      }

      case 'set_role': {
        const { data: requester } = await supabaseAdmin
          .from('users').select('role').eq('discord_id', discord_id).single()

        if (requester?.role !== 'admin') {
          return NextResponse.json({ error: 'Seul un admin peut changer les rôles.' })
        }

        await supabaseAdmin
          .from('users')
          .update({ role: data.role })
          .eq('discord_id', data.target_discord_id)

        return NextResponse.json({ success: true })
      }

      default:
        return NextResponse.json({ error: `Action inconnue: ${action}` }, { status: 400 })
    }
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
