import NextAuth, { NextAuthOptions } from 'next-auth'
import DiscordProvider from 'next-auth/providers/discord'
import { supabaseAdmin } from '@/lib/supabase'

export const authOptions: NextAuthOptions = {
  providers: [
    DiscordProvider({
      clientId: process.env.DISCORD_CLIENT_ID!,
      clientSecret: process.env.DISCORD_CLIENT_SECRET!,
      authorization: { params: { scope: 'identify email guilds' } },
    }),
  ],
  callbacks: {
    async signIn({ user, account, profile }) {
      if (account?.provider === 'discord' && profile) {
        const discordProfile = profile as any
        try {
          // Upsert user in Supabase
          const { error } = await supabaseAdmin
            .from('users')
            .upsert({
              discord_id: discordProfile.id,
              username: discordProfile.username,
              discriminator: discordProfile.discriminator || '0',
              avatar: discordProfile.avatar
                ? `https://cdn.discordapp.com/avatars/${discordProfile.id}/${discordProfile.avatar}.png`
                : null,
              email: user.email,
              last_login: new Date().toISOString(),
            }, { onConflict: 'discord_id' })

          if (error) console.error('Supabase upsert error:', error)
        } catch (e) {
          console.error('SignIn error:', e)
        }
      }
      return true
    },

    async jwt({ token, account, profile }) {
      if (account?.provider === 'discord' && profile) {
        const discordProfile = profile as any
        token.discordId = discordProfile.id
        token.avatar = discordProfile.avatar
          ? `https://cdn.discordapp.com/avatars/${discordProfile.id}/${discordProfile.avatar}.png`
          : null

        // Fetch role from Supabase
        const { data } = await supabaseAdmin
          .from('users')
          .select('role, id')
          .eq('discord_id', discordProfile.id)
          .single()

        token.role = data?.role || 'member'
        token.userId = data?.id
      }
      return token
    },

    async session({ session, token }) {
      if (token) {
        session.user.discordId = token.discordId as string
        session.user.avatar = token.avatar as string
        session.user.role = token.role as string
        session.user.userId = token.userId as string
      }
      return session
    },
  },
  pages: {
    signIn: '/login',
    error: '/login',
  },
  session: { strategy: 'jwt' },
}

const handler = NextAuth(authOptions)
export { handler as GET, handler as POST }
