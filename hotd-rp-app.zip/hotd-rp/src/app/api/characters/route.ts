import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/app/api/auth/[...nextauth]/route'
import { supabaseAdmin } from '@/lib/supabase'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const houseId = searchParams.get('house_id')
  const status = searchParams.get('status')
  const search = searchParams.get('search')

  let query = supabaseAdmin
    .from('characters')
    .select(`*, house:houses(*), player:users(username, avatar, discord_id)`)
    .order('name')

  if (houseId) query = query.eq('house_id', houseId)
  if (status) query = query.eq('status', status)
  if (search) query = query.ilike('name', `%${search}%`)

  const { data, error } = await query
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data)
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const isAdmin = ['admin', 'moderator'].includes(session.user.role)

  // Limit: members can only create 1 character unless admin
  if (!isAdmin) {
    const { count } = await supabaseAdmin
      .from('characters')
      .select('*', { count: 'exact', head: true })
      .eq('player_discord_id', session.user.discordId)

    if ((count || 0) >= 3) {
      return NextResponse.json({ error: 'Limite de 3 personnages atteinte' }, { status: 403 })
    }
  }

  const { data, error } = await supabaseAdmin
    .from('characters')
    .insert({
      ...body,
      player_discord_id: session.user.discordId,
      player_id: session.user.userId,
      created_by: session.user.userId,
    })
    .select()
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data, { status: 201 })
}

export async function PUT(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const { id, ...updates } = body
  const isAdmin = ['admin', 'moderator'].includes(session.user.role)

  let query = supabaseAdmin.from('characters').update(updates).eq('id', id)
  if (!isAdmin) query = query.eq('player_discord_id', session.user.discordId)

  const { data, error } = await query.select().single()
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data)
}

export async function DELETE(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session || !['admin', 'moderator'].includes(session.user.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  const { searchParams } = new URL(req.url)
  const id = searchParams.get('id')

  const { error } = await supabaseAdmin.from('characters').delete().eq('id', id!)
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ success: true })
}
