'use client'
import { useSession, signOut } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Character, House } from '@/types'

export default function Dashboard() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [characters, setCharacters] = useState<Character[]>([])
  const [houses, setHouses] = useState<House[]>([])
  const [loading, setLoading] = useState(true)
  const [showCreateModal, setShowCreateModal] = useState(false)

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login')
  }, [status, router])

  useEffect(() => {
    if (status === 'authenticated') {
      fetchData()
    }
  }, [status])

  async function fetchData() {
    setLoading(true)
    const [charsRes, housesRes] = await Promise.all([
      fetch('/api/characters'),
      fetch('/api/families'),
    ])
    const charsData = await charsRes.json()
    const housesData = await housesRes.json()
    setCharacters(Array.isArray(charsData) ? charsData : [])
    setHouses(Array.isArray(housesData) ? housesData : [])
    setLoading(false)
  }

  const myCharacters = characters.filter(c => c.player_discord_id === session?.user?.discordId)
  const isAdmin = ['admin', 'moderator'].includes(session?.user?.role || '')

  if (status === 'loading' || loading) {
    return <div style={styles.loading}><span style={{ fontSize: 48 }}>🐉</span><p>Chargement de Westeros...</p></div>
  }

  return (
    <div style={styles.root}>
      <nav style={styles.nav}>
        <div style={styles.navBrand}>
          <span>🐉</span>
          <span style={styles.navTitle}>HOTD RP</span>
        </div>
        <div style={styles.navLinks}>
          <Link href="/dashboard" style={styles.navLink}>Tableau de bord</Link>
          <Link href="/tree" style={styles.navLink}>🌳 Arbre généalogique</Link>
          {isAdmin && <Link href="/admin" style={styles.navLinkAdmin}>⚔️ Admin</Link>}
        </div>
        <div style={styles.navUser}>
          <img src={session?.user?.avatar || session?.user?.image || '/default-avatar.png'} alt="" style={styles.avatar} />
          <span style={styles.username}>{session?.user?.name}</span>
          {isAdmin && <span style={styles.roleBadge}>{session?.user?.role}</span>}
          <button onClick={() => signOut({ callbackUrl: '/login' })} style={styles.signOutBtn}>Déconnexion</button>
        </div>
      </nav>

      <main style={styles.main}>
        <div style={styles.hero}>
          <h1 style={styles.heroTitle}>Bienvenue, <span style={styles.heroName}>{session?.user?.name}</span></h1>
          <p style={styles.heroSub}>Arbre Généalogique des Sept Couronnes</p>
        </div>

        <div style={styles.grid}>
          {/* My Characters */}
          <section style={styles.section}>
            <div style={styles.sectionHeader}>
              <h2 style={styles.sectionTitle}>⚔️ Mes Personnages</h2>
              <button onClick={() => setShowCreateModal(true)} style={styles.createBtn}>+ Nouveau</button>
            </div>
            {myCharacters.length === 0 ? (
              <div style={styles.emptyState}>
                <p>Tu n'as pas encore de personnage.</p>
                <button onClick={() => setShowCreateModal(true)} style={styles.createBtnLarge}>Créer mon premier personnage</button>
              </div>
            ) : (
              <div style={styles.charList}>
                {myCharacters.map(char => (
                  <CharacterCard key={char.id} char={char} onUpdate={fetchData} isOwner />
                ))}
              </div>
            )}
          </section>

          {/* All Characters */}
          <section style={styles.section}>
            <h2 style={styles.sectionTitle}>🏰 Tous les personnages ({characters.length})</h2>
            <div style={styles.charListSmall}>
              {characters.map(char => (
                <CharacterCard key={char.id} char={char} compact />
              ))}
            </div>
          </section>

          {/* Houses */}
          <section style={styles.section}>
            <h2 style={styles.sectionTitle}>🛡️ Maisons Nobles</h2>
            <div style={styles.houseGrid}>
              {houses.map(house => (
                <div key={house.id} style={{ ...styles.houseCard, borderColor: house.color_primary }}>
                  <span style={styles.houseSigil}>{house.sigil || '🏰'}</span>
                  <strong style={{ ...styles.houseName, color: house.color_primary }}>{house.name}</strong>
                  <p style={styles.houseWords}><em>"{house.words}"</em></p>
                </div>
              ))}
            </div>
          </section>
        </div>
      </main>

      {showCreateModal && (
        <CreateCharacterModal
          houses={houses}
          onClose={() => setShowCreateModal(false)}
          onCreated={() => { setShowCreateModal(false); fetchData() }}
        />
      )}
    </div>
  )
}

function CharacterCard({ char, compact, isOwner, onUpdate }: {
  char: Character; compact?: boolean; isOwner?: boolean; onUpdate?: () => void
}) {
  const statusColors = { alive: '#4ade80', dead: '#ef4444', unknown: '#94a3b8', dragon: '#f97316' }

  async function deleteChar() {
    if (!confirm(`Supprimer ${char.name} ?`)) return
    await fetch(`/api/characters?id=${char.id}`, { method: 'DELETE' })
    onUpdate?.()
  }

  return (
    <div style={{ ...styles.charCard, ...(compact ? styles.charCardCompact : {}) }}>
      {char.avatar_url
        ? <img src={char.avatar_url} alt="" style={styles.charAvatar} />
        : <div style={{ ...styles.charAvatarDefault, background: char.house?.color_primary || '#8B0000' }}>
            {char.name[0]}
          </div>
      }
      <div style={styles.charInfo}>
        <div style={styles.charName}>{char.title ? `${char.title} ` : ''}{char.name}</div>
        {!compact && <div style={styles.charHouse}>{char.house?.sigil} {char.house?.name || 'Sans maison'}</div>}
        <div style={{ ...styles.charStatus, color: statusColors[char.status] }}>● {char.status}</div>
      </div>
      {isOwner && !compact && (
        <button onClick={deleteChar} style={styles.deleteBtn} title="Supprimer">✕</button>
      )}
    </div>
  )
}

function CreateCharacterModal({ houses, onClose, onCreated }: {
  houses: House[]; onClose: () => void; onCreated: () => void
}) {
  const [form, setForm] = useState({
    name: '', title: '', age: '', gender: 'unknown', house_id: '', description: '', status: 'alive'
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function submit() {
    if (!form.name.trim()) return setError('Le nom est requis')
    setLoading(true)
    const res = await fetch('/api/characters', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...form, age: form.age ? parseInt(form.age) : null }),
    })
    const data = await res.json()
    setLoading(false)
    if (data.error) return setError(data.error)
    onCreated()
  }

  return (
    <div style={styles.modalOverlay} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={styles.modal}>
        <h2 style={styles.modalTitle}>🐉 Nouveau Personnage</h2>
        {error && <p style={styles.errorMsg}>{error}</p>}
        <div style={styles.formGrid}>
          <label style={styles.label}>Nom *</label>
          <input style={styles.input} value={form.name} onChange={e => setForm({...form, name: e.target.value})} placeholder="Nom du personnage" />
          <label style={styles.label}>Titre</label>
          <input style={styles.input} value={form.title} onChange={e => setForm({...form, title: e.target.value})} placeholder="Ser, Lord, Prince..." />
          <label style={styles.label}>Maison</label>
          <select style={styles.input} value={form.house_id} onChange={e => setForm({...form, house_id: e.target.value})}>
            <option value="">Sans maison</option>
            {houses.map(h => <option key={h.id} value={h.id}>{h.sigil} {h.name}</option>)}
          </select>
          <label style={styles.label}>Genre</label>
          <select style={styles.input} value={form.gender} onChange={e => setForm({...form, gender: e.target.value})}>
            <option value="unknown">Inconnu</option>
            <option value="male">Masculin</option>
            <option value="female">Féminin</option>
            <option value="other">Autre</option>
          </select>
          <label style={styles.label}>Âge</label>
          <input style={styles.input} type="number" value={form.age} onChange={e => setForm({...form, age: e.target.value})} placeholder="Âge" />
          <label style={styles.label}>Description</label>
          <textarea style={{...styles.input, height: 80, resize: 'vertical'}} value={form.description} onChange={e => setForm({...form, description: e.target.value})} placeholder="Décris ton personnage..." />
        </div>
        <div style={styles.modalActions}>
          <button onClick={onClose} style={styles.cancelBtn}>Annuler</button>
          <button onClick={submit} disabled={loading} style={styles.submitBtn}>
            {loading ? 'Création...' : '✅ Créer le personnage'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ─── Styles ───────────────────────────────────────────────────
const styles: Record<string, React.CSSProperties> = {
  root: { minHeight: '100vh', background: '#0d0508', color: '#e8d5b0', fontFamily: "'Crimson Text', Georgia, serif" },
  loading: { display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', gap: 16, color: '#e8c070', background: '#0d0508', fontSize: '1.2rem' },
  nav: { display: 'flex', alignItems: 'center', padding: '0.75rem 2rem', background: 'rgba(10,4,8,0.95)', borderBottom: '1px solid rgba(180,80,20,0.3)', gap: 24, flexWrap: 'wrap' },
  navBrand: { display: 'flex', alignItems: 'center', gap: 8, fontSize: '1.4rem' },
  navTitle: { fontFamily: 'Cinzel, serif', fontWeight: 700, color: '#e8c070', letterSpacing: '0.1em' },
  navLinks: { display: 'flex', gap: 16, flex: 1 },
  navLink: { color: 'rgba(200,160,100,0.8)', textDecoration: 'none', fontFamily: 'Cinzel, serif', fontSize: '0.85rem', letterSpacing: '0.05em' },
  navLinkAdmin: { color: '#ef4444', textDecoration: 'none', fontFamily: 'Cinzel, serif', fontSize: '0.85rem' },
  navUser: { display: 'flex', alignItems: 'center', gap: 8 },
  avatar: { width: 32, height: 32, borderRadius: '50%', border: '1px solid rgba(200,100,30,0.4)' },
  username: { color: '#e8c070', fontWeight: 600, fontSize: '0.9rem' },
  roleBadge: { background: '#8B0000', color: '#FFD700', padding: '2px 8px', borderRadius: 3, fontSize: '0.7rem', fontFamily: 'Cinzel, serif', textTransform: 'uppercase', letterSpacing: '0.05em' },
  signOutBtn: { background: 'transparent', border: '1px solid rgba(180,80,20,0.4)', color: 'rgba(200,160,100,0.7)', padding: '4px 12px', cursor: 'pointer', borderRadius: 3, fontSize: '0.8rem', fontFamily: 'Cinzel, serif' },
  main: { padding: '2rem', maxWidth: 1400, margin: '0 auto' },
  hero: { marginBottom: '2rem', textAlign: 'center', paddingBottom: '1.5rem', borderBottom: '1px solid rgba(180,80,20,0.2)' },
  heroTitle: { fontFamily: 'Cinzel, serif', fontSize: '1.8rem', fontWeight: 700, color: '#e8c070', marginBottom: 8 },
  heroName: { color: '#FFD700' },
  heroSub: { color: 'rgba(200,160,100,0.6)', fontStyle: 'italic', fontSize: '1.05rem' },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 24 },
  section: { background: 'rgba(15,6,10,0.6)', border: '1px solid rgba(180,80,20,0.2)', borderRadius: 6, padding: '1.5rem' },
  sectionHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' },
  sectionTitle: { fontFamily: 'Cinzel, serif', fontSize: '1rem', color: '#e8c070', letterSpacing: '0.08em', marginBottom: '1rem' },
  createBtn: { background: '#8B0000', border: 'none', color: '#FFD700', padding: '6px 14px', cursor: 'pointer', borderRadius: 3, fontFamily: 'Cinzel, serif', fontSize: '0.8rem' },
  createBtnLarge: { display: 'block', margin: '1rem auto', background: '#8B0000', border: 'none', color: '#FFD700', padding: '10px 20px', cursor: 'pointer', borderRadius: 3, fontFamily: 'Cinzel, serif', fontSize: '0.9rem' },
  emptyState: { textAlign: 'center', color: 'rgba(200,160,100,0.5)', padding: '2rem 0' },
  charList: { display: 'flex', flexDirection: 'column', gap: 8 },
  charListSmall: { display: 'flex', flexDirection: 'column', gap: 6, maxHeight: 400, overflowY: 'auto' },
  charCard: { display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', background: 'rgba(20,8,12,0.8)', border: '1px solid rgba(180,80,20,0.15)', borderRadius: 4, position: 'relative' },
  charCardCompact: { padding: '6px 10px' },
  charAvatar: { width: 40, height: 40, borderRadius: '50%', objectFit: 'cover' },
  charAvatarDefault: { width: 40, height: 40, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#FFD700', fontWeight: 700, fontSize: '1.1rem', flexShrink: 0 },
  charInfo: { flex: 1, minWidth: 0 },
  charName: { fontFamily: 'Cinzel, serif', fontSize: '0.9rem', color: '#e8c070', fontWeight: 600 },
  charHouse: { fontSize: '0.82rem', color: 'rgba(200,160,100,0.6)', marginTop: 2 },
  charStatus: { fontSize: '0.75rem', marginTop: 2 },
  deleteBtn: { background: 'transparent', border: 'none', color: 'rgba(200,80,60,0.5)', cursor: 'pointer', fontSize: '1rem', padding: 4 },
  houseGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: 10 },
  houseCard: { padding: '12px', background: 'rgba(20,8,12,0.8)', border: '1px solid', borderRadius: 4, textAlign: 'center' },
  houseSigil: { fontSize: 28, display: 'block', marginBottom: 6 },
  houseName: { display: 'block', fontFamily: 'Cinzel, serif', fontSize: '0.85rem', marginBottom: 4 },
  houseWords: { fontSize: '0.75rem', color: 'rgba(200,160,100,0.5)', lineHeight: 1.4 },
  modalOverlay: { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, padding: '1rem' },
  modal: { background: '#0f0608', border: '1px solid rgba(180,80,20,0.4)', borderRadius: 6, padding: '2rem', width: '100%', maxWidth: 500, maxHeight: '90vh', overflowY: 'auto' },
  modalTitle: { fontFamily: 'Cinzel, serif', color: '#e8c070', marginBottom: '1.5rem', textAlign: 'center' },
  formGrid: { display: 'flex', flexDirection: 'column', gap: 8, marginBottom: '1.5rem' },
  label: { fontSize: '0.8rem', color: 'rgba(200,160,100,0.7)', fontFamily: 'Cinzel, serif', letterSpacing: '0.05em' },
  input: { background: 'rgba(20,8,12,0.8)', border: '1px solid rgba(180,80,20,0.3)', borderRadius: 3, padding: '8px 12px', color: '#e8d5b0', fontSize: '0.95rem', fontFamily: "'Crimson Text', Georgia, serif", width: '100%' },
  modalActions: { display: 'flex', gap: 10, justifyContent: 'flex-end' },
  cancelBtn: { background: 'transparent', border: '1px solid rgba(180,80,20,0.3)', color: 'rgba(200,160,100,0.6)', padding: '8px 18px', cursor: 'pointer', borderRadius: 3, fontFamily: 'Cinzel, serif', fontSize: '0.85rem' },
  submitBtn: { background: '#8B0000', border: 'none', color: '#FFD700', padding: '8px 18px', cursor: 'pointer', borderRadius: 3, fontFamily: 'Cinzel, serif', fontSize: '0.85rem', fontWeight: 600 },
  errorMsg: { color: '#ef4444', marginBottom: 12, fontSize: '0.9rem' },
}
